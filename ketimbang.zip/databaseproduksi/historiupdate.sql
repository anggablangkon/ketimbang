 -- menampung view orang yang melihat postingan
 alter table postingan add views int(10)null after foto;