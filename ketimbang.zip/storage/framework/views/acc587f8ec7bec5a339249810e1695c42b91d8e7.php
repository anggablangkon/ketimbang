<?php $__env->startSection('content'); ?>
<!-- content -->
<div class="card m-b-30">
	<div class="card card-body">

		<a href="<?php echo e(url('/tambahpostingan')); ?>" class="btn btn-primary" <?php if(!app('mobile-detect')->isMobile()) : ?> style="width: 20%;" <?php endif; ?>>
			<i class="dripicons-document-new"></i>
			Buat Post Baru
		</a>

		<hr/>
		<div class="table-responsive">
		<table id="datatable" class="table  table-striped table-bordered nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%; font-size: 12px;">
			<thead>
				<tr>
					<th>No</th>
					<th>Foto</th>
					<th>Judul</th>
					<th>Tanggal Post</th>
					<th>Jenis Post</th>
					<th>Oleh</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php $no = 1; ?>
				<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tampil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($no++); ?></td>
					<td>
						<?php if(strlen($tampil->foto) >= 6): ?>
		                  <img src="<?php echo e(asset($tampil->foto)); ?>" width="50px" height="50px">
		                <?php else: ?>
							<img src="<?php echo e(asset('imagepost/' .$tampil->id.'.'.$tampil->foto)); ?>" width="50px" height="50px">
		                <?php endif; ?>
					</td>
					<td><?php echo e($tampil->judul); ?></td>
					<td><?php echo e($tampil->date); ?></td>
					<td>
						<?php if($tampil->jenispost == 'Donasi'): ?>
						<span class="badge badge-primary"><?php echo e(strtoupper($tampil->jenispost)); ?></span>
						<?php else: ?>
						<span class="badge badge-danger"><?php echo e(strtoupper($tampil->jenispost)); ?></span>
						<?php endif; ?>
					</td>
					<td><?php echo e($tampil->name); ?></td>
					<td>
						<a title="hapus" href="" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#myModal">
							<i class="dripicons-cross"></i>
						</a>
						<!-- Modal digunakan untuk popuv delete data -->
						<div class="modal fade" id="myModal" role="dialog">
							<div class="modal-dialog">

								<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4 class="modal-title">Pemberitahuan Sistem</h4>
									</div>
									<div class="modal-body">
										<p>Apakah Anda Yakin Akan Menghapus data <b><?php echo e($tampil->judul); ?></b></p>
										<p>Jika Benar Tekan Tombol <a class="btn btn-danger" href="<?php echo e(url('/hapuspostingan')); ?>/<?php echo e($tampil->id); ?>">Hapus</a></p>
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
									</div>
								</div>

							</div>
						</div>
						<a  href="<?php echo e(url('/editpostingan')); ?>/<?php echo e($tampil->id); ?>" class="btn btn-sm btn-info">
							<i class="dripicons-document-edit"></i>
						</a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		</div>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layoutsadminnew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Apache24\htdocs\ketimbang\resources\views//admin/lihatpostingan.blade.php ENDPATH**/ ?>