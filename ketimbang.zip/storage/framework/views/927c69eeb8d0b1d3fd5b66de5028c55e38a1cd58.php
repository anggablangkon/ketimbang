<?php $__env->startSection('title', 'Masuk Kedalam Sistem'); ?>

<?php $__env->startSection('halamanatas'); ?>

    <div class="container">      
        <div class="row space-100">
          <div class="col-lg-12 col-md-12 col-xs-12">
            <div class="contents">
             <center>

                 <div class="row">
                    <div class="col-12 form-line">
                    <h2>Login Kedalam Sistem</h2>

                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="email" class="col-md-3 col-form-label text-md-right"></label>

                            <div class="col-md-6">
                                <input id="email" autocomplete="off" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required autofocus>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>Maaf Email Anda Tidak Terdaftar!</strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-3 col-form-label text-md-right"></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="Password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong>Maaf! Password Yang Anda Masukan Salah.</strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-3 col-form-label text-md-right"></label>

                            <div class="col-md-6">
                                 <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Masuk')); ?>

                                </button>
                                <a href="<?php echo e(url('/')); ?>" class="btn btn-danger"> Kembali </a>

                            </div>

                        </div>
                    </form>

                    </div>
                  </div>

             </center>
            </div>
          </div>
        </div> 
    </div>  

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Apache24\htdocs\ketimbang\resources\views/auth/login.blade.php ENDPATH**/ ?>