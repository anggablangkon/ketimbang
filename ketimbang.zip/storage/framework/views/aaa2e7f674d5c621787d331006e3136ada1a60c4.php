<?php $__env->startSection('title','Ketimbang Ngemis Pandeglang'); ?>

<?php $__env->startSection('css'); ?>
  <style type="text/css">
    .kokitindo {
      width: 100%; 
      font-size: 12px; 
      border-radius: 0px;
      padding: 6px;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

&nbsp;
<!-- Awesome Screens Section Start -->
<section id="" class="screens-shot section">
  <div class="container">
    <div class="">   
      <div class="row">
        <!-- start content -->
        <div class="col-lg-7">
          &nbsp;
          <div class="alert alert-success alert-dismissible">
            <p>
              Bantu knpandeglang.com dengan menjadi Fundraiser. Setiap donasi yang Anda kumpulkan akan disalurkan ke "#Orang Yang Membutuhkan". 
            </p>
          </div>    

          <!--   postingan -->
          <?php if(!app('mobile-detect')->isMobile()) : ?>
          <center>
            <?php if(strlen($postingan->foto) >= 6): ?>
            <img src="<?php echo e(asset($postingan->foto)); ?>" style="width: 100%; height: 300px;">
            <?php else: ?>
            <img src="<?php echo e(asset('/imagepost')); ?>/<?php echo e($postingan->id); ?>.<?php echo e($postingan->foto); ?>" style="width: 100%; height: 300px;">
            <?php endif; ?>
          </center>
          <?php endif; ?>
          <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
          <?php if(strlen($postingan->foto) >= 6): ?>
          <img src="<?php echo e(asset($postingan->foto)); ?>" style="width: 100%" height="300px">
          <?php else: ?>
          <img src="<?php echo e(asset('/imagepost')); ?>/<?php echo e($postingan->id); ?>.<?php echo e($postingan->foto); ?>" style="width: 100%" height="300px">
          <?php endif; ?>
          <?php endif; ?>
          
          <br/>
          <div style="color: black;">
            <p>Postingan dibuat oleh : <a href=""><?php echo e($postingan->name); ?> </a> & telah dilihat sebanyak : <?php echo e($postingan->views); ?> kali</p><hr/>
            <?php echo $postingan->isi; ?>

          </div>
          <br/>
          <b>
            Share To  :
            <a href="whatsapp://send?text=https://knpandeglang.com/lihatdonasi/<?php echo e($postingan->slug); ?>" target="_blank" class="btn-sm btn-success">Whatsapp</a>
            <a href="http://www.facebook.com/sharer.php?u=https://knpandeglang.com/lihatdonasi/<?php echo e($postingan->slug); ?>" class="btn-sm btn-primary" target="_blank">Facebook</a>
            <a href="https://twitter.com/share?url=https://knpandeglang.com/lihatdonasi/<?php echo e($postingan->slug); ?>" target="_blank" class="btn-sm btn-info">twitter</a>
            <!--<a href="https://plus.google.com/share?url=https://knpandeglang.com/lihatdonasi/<?php echo e($postingan->slug); ?>" target="_blank" class="btn-sm btn-danger">Google Plus</a>-->
          </b>

        </div>
        <div class="col-lg-5">
          <div class="panel panel-default">
            <div class="panel-body">

              <br/>
              
              <?php if(!app('mobile-detect')->isMobile()) : ?>
              <div class="card bg-light text-dark">
                <div class="card-body">

                  <div class="team-details">
                    <div class="team-inner">
                      <h4 class="team-title">

                        <center>
                          <h6>Hubungi Kami Untuk Melakukan Donasi</h6>
                        </center>
                        <a href="https://api.whatsapp.com/send?phone=6283806354663&text=Assalammualaikum%20Admin%20Saya%20Ingin%20Berdonasi%20Untuk%20Projek%20:%20<?php echo e($postingan->slug); ?>" class="btn btn-success kokitindo"> Whatsapp </a>
                        <a href="https://www.facebook.com/ketimbang.ngemis.pandeglang90" class="btn btn-primary kokitindo" style="width: 100%; font-size: 12px;" > Facebook </a>
                        <a href="https://www.instagram.com/ketimbang.ngemis.pandeglang/" class="btn btn-danger kokitindo" style="width: 100%; font-size: 12px;"> Instagram </a>

                      </h4>
                    </div>
                  </div>
                
                </div>
              </div>
              <?php endif; ?>

                <br/>
                <div class="card bg-light text-dark">
                <div class="card-body">
                  <div class="team-details">
                    <div class="team-inner">
                      <h6 class="team-title">

                        <b>Donasi Lainnya</b>
                        <br/><br/>
                        <ul>
                          <?php $no = 1; ?> 
                          <?php $__currentLoopData = $donasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postingan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li><?php echo e($no++); ?>. <a href="<?php echo e(url('/lihatdonasi')); ?>/<?php echo e($postingan->slug); ?>"><?php echo e($postingan->judul); ?></a></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                      </h6>
                    </div>
                  </div>
                </div>
                </div>
              



            </div>
          </div>
        </div>
      </div>
    </div>


    
  </div>
</section>
<!-- Awesome Screens Section End -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Apache24\htdocs\ketimbang\resources\views//lihatdonasi.blade.php ENDPATH**/ ?>