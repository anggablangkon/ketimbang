<?php $__env->startSection('title','Ketimbang Ngemis Pandeglang'); ?>


<?php $__env->startSection('content'); ?>
    
    &nbsp;
  <!-- Awesome Screens Section Start -->
    <section id="" class="screens-shot section">
      <div class="container">
        <div class="section-header">   
          <div class="row">
            <!-- start content -->
            <div class="col-sm-2">
            </div>
            <div class="col-lg-8">
              <!--<p class="btn btn-subtitle wow fadeInDown" data-wow-delay="0.2s">TENTANG KAMI</p>-->
            </div>
          </div>
        </div>
        <div class="row">

            <!-- start content -->
            <div class="col-sm-2">
            </div>
            <div class="col-lg-8">
              <?php if(!app('mobile-detect')->isMobile()) : ?>
              <center>
              <!--<img src="<?php echo e(asset('images/knp.PNG')); ?>" style="width: 300px; height: 300px;">-->
              </center>
              <?php endif; ?>
              <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
              <!--<img src="<?php echo e(asset('images/knp.PNG')); ?>" style="width: 100%; height: 400px;">-->
              <?php endif; ?>
              <center>
              <p class="btn btn-subtitle wow fadeInDown" data-wow-delay="0.2s">TENTANG KAMI</p>       
              <!--<p class="btn btn-subtitle wow fadeInDown" data-wow-delay="0.2s"></p>       -->
              </center>
              <br/>
              <p style="text-align:justify;">
                <?php echo $layouts->isi; ?>

              </p>

              <br/>
                <b>
                  Share To  :
                  <a href="whatsapp://send?text=http://knp/public/lihatdonasi/<?php echo e(url('/tentangkami')); ?>" target="_blank" class="btn-sm btn-success">Whatsapp</a>
                  <a href="http://www.facebook.com/sharer.php?u=http://knp/public/lihatdonasi/<?php echo e(url('/tentangkami')); ?>" class="btn-sm btn-primary" target="_blank">Facebook</a>
                  <a href="https://twitter.com/share?url=http://knp/public/lihatdonasi/<?php echo e(url('/tentangkami')); ?>" target="_blank" class="btn-sm btn-info">twitter</a>
                  <!--<a href="https://plus.google.com/share?url=http://knp/public/lihatdonasi/<?php echo e(url('/tentangkami')); ?>" target="_blank" class="btn-sm btn-danger">Google Plus</a>-->
                </b>
                </b>
            </div>
            <!-- end content -->

        </div>
      </div>
    </section>
    <!-- Awesome Screens Section End -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Apache24\htdocs\ketimbang\resources\views//tentangkami.blade.php ENDPATH**/ ?>