<?php $__env->startSection('title','Ketimbang Ngemis Pandeglang'); ?>

<?php $__env->startSection('halamanatas'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Blog Section -->
<section id="blog" class="section">
  <!-- Container Starts -->
  <div class="container">
    <br/>

    <div class="row">

      <div class="col-sm-9">
        <h5 class="h5" style="font-weight: bold; color: black;">Postingan Blogs Member</h5>

        <div class="row">
          <div class="col-sm-8" style="padding-top: 15px; color: black;">
            Cari Aktivitas Baru, <?php echo e(count($donasi)); ?> aktivitas membutuhkan bantuan
          </div>
          <div class="col-sm-3" >
            <button class="btn btn-primary btn-sm"  data-toggle="collapse" href="#collapseOne" style="color: black;">
              <i class='lni lni-angle-double-down'></i>
              Filter Search
            </button>
          </div>
        </div>

        <hr/>

        <div id="collapseOne" class="collapse"  data-parent="#accordion">
          <form action="<?php echo e(url('/searchdonasi')); ?>" method="post">
            <?php echo e(csrf_Field()); ?>

            <div class="row">
             <div class="col-sm-9">
               <input type="text" class="form-control" style="width: 100%; height: 50%; text-align: left; border-color: blue;" name="search">
             </div>
             <div class="col-sm-3">
               <button class="btn btn-success"> Terapkan</button>
             </div>
           </div>
         </form>
         <hr/>
       </div>

       <div class="row">

        <?php $__currentLoopData = $donasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tampil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(url('/lihatdonasi')); ?>/<?php echo e($tampil->slug); ?>">
          <div class="col-lg-4 col-md-6 col-xs-12 blog-item" style="padding-bottom: 10px; color: #403636;">
            <!-- Blog Item Starts -->
            <div class="blog-item-wrapper">
              <div class="blog-item-img">
                <?php if(strlen($tampil->foto) >= 6): ?>
                <img src="<?php echo e(asset($tampil->foto)); ?>" style="height: 150px" alt="">
                <?php else: ?>
                <img src="<?php echo e(asset('/imagepost')); ?>/<?php echo e($tampil->id); ?>.<?php echo e($tampil->foto); ?>" style="height: 150px" alt="">
                <?php endif; ?>
              </div>
              <div class="blog-item-text"> 
                <a href="<?php echo e(url('/lihatdonasi')); ?>/<?php echo e($tampil->slug); ?>" style="font-size: 14px;"><?php echo e(strtoupper(substr($tampil->judul, 0, 30))); ?>..</a>
                <?php if(strlen($tampil->judul) < 25): ?>
                <br/><br/>
                <?php endif; ?>
                <div class="author">
                  <span class="name"><a style="color: #403636;" href="#">Oleh : <?php echo e($tampil->name); ?></a></span>
                  
                </div>
              </div>
            </div>
            <!-- Blog Item Wrapper Ends-->
          </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>

      
  </div>


  <div class="col-sm-3">
   <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
   <br/>
   <?php endif; ?>
   <h5 class="h5" style="font-weight: bold; color: black;">Iklan Adsense</h5>

   <div class="card bg-light text-dark">
    <div class="card-body">


    </div>
  </div>
</div>

</div>
</div>
</section>
<!-- blog Section End -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Apache24\htdocs\ketimbang\resources\views//aktifitasdonasi.blade.php ENDPATH**/ ?>