<?php $__env->startSection('content'); ?>
<!-- content -->
<div class="card m-b-30">
	<div class="card card-body">

		<hr/>
		<div class="table-responsive">
		<table id="datatable" class="table  table-striped table-bordered nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%; font-size: 12px;">
			<thead>
				<tr>
					<th>Nama Halaman</th>
					<th>Title</th>
					<th>Editing</th>
					<th>Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $layouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($values->nama_menu); ?></td>
					<td><?php echo e($values->title); ?></td>
					<td><?php echo e($values->name); ?></td>
					<td>
						<a title="hapus" href="" class="btn btn-sm btn-danger">
							<i class="dripicons-cross"></i>
						</a>
						<a  href="<?php echo e(url('/editlayouts')); ?>/<?php echo e($values->id); ?>" class="btn btn-sm btn-info">
							<i class="dripicons-document-edit"></i>
						</a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		</div>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layoutsadminnew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Apache24\htdocs\ketimbang\resources\views/admin/layouts/layoutsedit.blade.php ENDPATH**/ ?>