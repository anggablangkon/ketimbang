


<!--Morris Chart CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/morris/morris.css')); ?>">

<link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/icons.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" type="text/css">

<!-- DataTables -->
<link href="<?php echo e(asset('assets/plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

<script src="<?php echo e(asset('assets/plugins/tinymce/tinymce.min.js')); ?>"></script>
<?php /**PATH E:\Apache24\htdocs\ketimbang\resources\views/layouts/assetsadmin/css.blade.php ENDPATH**/ ?>