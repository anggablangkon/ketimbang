<?php $__env->startSection('content'); ?>

<div class="row">

	<!-- membuat alert selamat datang -->
	<div class="col-sm-12">

		<div class="alert alert-success" style="color: black;">
			<strong> Hallo </strong> <?php echo e(Auth::user()->name); ?>, Selamat datang dihalaman <b>Dashboard</b>
		</div>

		<div class="row">

		</div>

	</div>


</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layoutsadminnew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Apache24\htdocs\ketimbang\resources\views/home.blade.php ENDPATH**/ ?>