<?php $__env->startSection('title','Ketimbang Ngemis Pandeglang'); ?>

<?php $__env->startSection('halamanatas'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- Blog Section -->
<section id="blog" class="section">
  <!-- Container Starts -->
  <div class="container">
    <br/>

    <div class="row">

      <div class="col-sm-8">
        <div class="card bg-light text-dark">
          <div class="card-body">

            <!-- <div class="single-team wow fadeInUp" data-wow-delay="0.2s"> -->
              <div class="team-details">
                <div class="team-inner">


                  <h5 class="h5" style="font-weight: bold; color: black;"><?php echo e(strtoupper($postingan->judul)); ?></h5>
                  <p>Tanggal Post : <?php echo e($postingan->date); ?> <i class="lni lni-eye"></i> <?php echo e($postingan->views); ?></p>
                  <hr/>
                  <?php if(!app('mobile-detect')->isMobile()) : ?>
                  <center>
                    <img <?php if(strlen($postingan->foto) >= 6): ?> src="<?php echo e(asset($postingan->foto)); ?>" <?php else: ?> src="<?php echo e(asset('/imagepost')); ?>/<?php echo e($postingan->id); ?>.<?php echo e($postingan->foto); ?>" <?php endif; ?> style="width: 100%;">
                  </center>
                  <?php endif; ?>
                  <?php if (app('mobile-detect')->isMobile() && !app('mobile-detect')->isTablet()) : ?>
                  <img <?php if(strlen($postingan->foto) >= 6): ?> src="<?php echo e(asset($postingan->foto)); ?>" <?php else: ?> src="<?php echo e(asset('/imagepost')); ?>/<?php echo e($postingan->id); ?>.<?php echo e($postingan->foto); ?>" <?php endif; ?> style="width: 100%; height: 250px;">
                  <?php endif; ?>
                  <br/>
                  <div style="text-align:justify; color:black;">
                    <?php echo $postingan->isi; ?>

                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>


        <div class="col-sm-4">

          <div class="card bg-light text-dark">
          <div class="card-body">
            <div class="team-details">
              <div class="team-inner">

                <center>
                  <img src="<?php echo e(asset('/images/anga.jpg')); ?>" alt="user" class="rounded-circle" style="width: 85px; height: 85px;">
                </center> 
                <br/>
                <div class="table-responsive">
                  <table class="table table-bordered mini table-striped" style="font-size: 12px;">
                    <tbody>
                      <tr>
                        <th>Penulis </th>
                        <th> <?php echo e($postingan->name); ?></th>
                      </tr>
                      <tr>
                        <th>Bergabung </th>
                        <th> <?php echo e($postingan->created_at); ?></th>
                      </tr>
                      <tr>
                        <th colspan="2">
                          <center>
                            <a class="btn btn-primary"><i class='lni lni-user'></i> Detail Profile </a>
                          </center>
                        </th>
                      </tr>
                    </tbody>
                  </table>
                </div>

              </div>
            </div>
          </div>
          </div>
          <br/>

          <div class="card bg-light text-dark">
          <div class="card-body">
            <div class="team-details">
              <div class="team-inner">
                <b>Tulisan trending yang dibuat :</b>
                <hr/>
                <?php $__currentLoopData = $listpost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul>
                  <li><?php echo e($no++); ?>. <a href="<?php echo e(url('/bacapostingan/')); ?>/<?php echo e($values->slug); ?>"><?php echo e(substr(strtoupper($values->judul),0,30)); ?> ..</a></li>
                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
          </div>

        </div>
      </div>
    </div>
  </section>
  <!-- blog Section End -->


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Apache24\htdocs\ketimbang\resources\views//bacapostingan.blade.php ENDPATH**/ ?>