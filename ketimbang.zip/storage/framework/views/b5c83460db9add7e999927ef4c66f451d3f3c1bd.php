<?php $__env->startSection('title', 'Tambah data postingan komunitas'); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="/resources/demos/style.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- content -->
<form action="<?php echo e(url('/saveeditlayouts')); ?>" method="post" enctype="multipart/form-data">
	<div class="row">
		<div class="col-sm-8" style="padding-bottom: 10px;">

			<?php echo $__env->make('assets/message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<div class="card card-body">
				<h5>Buat Postingan</h5>
				<hr/>
				<?php echo csrf_field(); ?>
				<!-- content -->
				<div class="form-group">
					<label>Masukan Judul Postingan</label>
					<input type="text" autocomplete="off" autofocus required  class="form-control" id="judul" value="<?php echo e($layouts->title); ?>" name="judul" disabled>


				</div>
				<textarea name="isi" class="form-control my-editor"><?php echo e($layouts->isi); ?></textarea>

				&nbsp;
				<input type="hidden" name="id" value="<?php echo e($layouts->id); ?>">
				<input type="submit" style="padding-bottom: 4px;" style="width:10px;" value="SIMPAN" class="btn btn-primary" name="simpan">
				<input type="reset" value="RESET" class="btn btn-warning" name="reset">
				<a href="<?php echo e(url('/layoutsedit')); ?>" class="btn btn-info">Kembali</a>
			</div>

		</div>

	</div>

</div>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('/kokitindo/postingan.js')); ?>" defer></script>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<script src="//netdna.bootstrapcdn.com/twitter-bootstrap/2.2.1/js/bootstrap.min.js"></script>


<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
	
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layoutsadminnew', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Apache24\htdocs\ketimbang\resources\views/admin/layouts/editlayouts.blade.php ENDPATH**/ ?>