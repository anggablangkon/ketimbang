
      <div class="overlay"></div>
      <nav class="navbar navbar-expand-md bg-inverse fixed-top scrolling-navbar">
        <div class="container">
          <a href="<?php echo e(url('/')); ?>" class="navbar-brand"><img src="<?php echo e(asset('/images/knp.PNG')); ?>" style="width: 50px;" alt=""></a>  
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <i class="lni-menu"></i>
          </button>
          <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav mr-auto w-100 justify-content-end">
              <li class="nav-item">
                <a class="nav-link page-scroll" href="<?php echo e(url('/')); ?>">HOME</a>
              </li>
              <li class="nav-item">
                <a class="nav-link page-scroll" href="<?php echo e(url('/tentangkami')); ?>">TENTANG KAMI</a>
              </li> 
              <li class="nav-item">
                <a class="nav-link page-scroll" href="<?php echo e(url('/kontakkami')); ?>">KONTAK KAMI</a>
              </li> 
              <li class="nav-item">
                <a class="nav-link page-scroll" href="<?php echo e(url('/rancangankerja')); ?>">RANCANGAN KERJA</a>
              </li> 
              <li class="nav-item">
                <a class="nav-link page-scroll" href="<?php echo e(url('/aktifitasdandonasi')); ?>">AKTIVITAS BLOGS </a>
              </li> 
              <li class="nav-item">
                <a class="nav-link page-scroll" href="<?php echo e(url('/aktifitasdonasi')); ?>">DONASI </a>
              </li>               
              <?php if(Route::has('login')): ?>
                <?php if(auth()->guard()->check()): ?>
                <li class="nav-item">
                  <a class="nav-link page-scroll" href="<?php echo e(url('/login')); ?>">DASHBOARD</a>
                </li>
                <?php else: ?> 
                <li class="nav-item">
                  <a class="nav-link page-scroll" href="<?php echo e(url('/login')); ?>">LOGIN</a>
                </li>
                <?php endif; ?>
              <?php endif; ?>
               
              </li> 
            </ul>
          </div>
        </div>
      </nav><?php /**PATH E:\Apache24\htdocs\ketimbang\resources\views/assets/navbar.blade.php ENDPATH**/ ?>