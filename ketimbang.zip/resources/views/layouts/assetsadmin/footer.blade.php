   <br/>
   <footer class="footer">
   	© 2018 - 2020 <b>Ketimbang Ngemis</b> <span class="d-none d-sm-inline-block"> - Powered Teknologi  <i class="mdi mdi-heart text-danger"></i> by Startup Kokitindo</span>
   </footer>