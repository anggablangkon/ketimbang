<!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script src="{{ asset('/js/jquery-min.js') }}"></script>
    <script src="{{ asset('/js/popper.min.js') }}"></script>
    <script src="{{ asset('/js/bootstrap.min.js') }}"></script>
    <script src="{{ asset('/js/owl.carousel.js') }}"></script> 
    <script src="{{ asset('/js/jquery.mixitup.js') }}"></script>       
    <script src="{{ asset('/js/jquery.nav.js') }}"></script>    
    <script src="{{ asset('/js/scrolling-nav.js') }}"></script>    
    <script src="{{ asset('/js/jquery.easing.min.js') }}"></script>     
    <script src="{{ asset('/js/wow.js') }}"></script>   
    <script src="{{ asset('/js/jquery.counterup.min.js') }}"></script>     
    <script src="{{ asset('/js/nivo-lightbox.js') }}"></script>     
    <script src="{{ asset('/js/jquery.magnific-popup.min.js') }}"></script>     
    <script src="{{ asset('/js/waypoints.min.js') }}"></script>      
    <script src="{{ asset('/js/form-validator.min.js') }}"></script>
    <script src="{{ asset('/js/contact-form-script.js') }}"></script>   
    <script src="{{ asset('/js/main.js') }}"></script>

    <!-- carausel -->
    