<?php /* C:\xampp\htdocs\knp\resources\views/admin/form/editpostingan.blade.php */ ?>
<?php $__env->startSection('title', 'Tambah data postingan komunitas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
		
		<div class="col-sm-3">
			
			<!-- membuat menu dashboar admin -->
			 <div class="panel-group" id="accordion">

			  <div class="panel panel-primary">
			    <div class="panel-heading">
			      <h4 class="panel-title">
			        <a data-toggle="collapse" style="text-decoration: none;" data-parent="#accordion" href="#collapse1">
			        Dashboard</a>
			      </h4>
			    </div>
			    <div id="collapse1" class="panel-collapse collapse in">
			      
			      <div class="panel-body">
			      <!-- content panel dashboard -->
			      	<?php echo $__env->make('assets/paneladmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			      <!-- end -->
			      </div>

			    </div>
			  </div>
			  
			</div> 
			<!-- end dashboard admin --->

		</div>

		<div class="col-sm-9">
			
			<!-- membuat menu dashboar admin -->
			 <div class="panel-group" id="accordion">

			  <div class="panel panel-primary">
			    <div class="panel-heading">
			      <h4 class="panel-title">
			        <a data-toggle="collapse" style="text-decoration: none;" data-parent="#accordion" href="#collapse2">
			        Hallo! <?php echo e(Auth::user()->name); ?></a>
			      </h4>
			    </div>
			    <div  class="panel-collapse collapse in">
			      <div class="panel-body">
			      <!-- content panel dashboard -->
			      <?php echo $__env->make('assets/message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			      <!-- breadacumb -->
			         <ol class="breadcrumb" style="background-color: none">
					    <li><a href="<?php echo e(url('/home')); ?>">Home</a></li>
					    <li><a href="<?php echo e(url('/tambahpostingan')); ?>" class="activer">Tambah Postingan</a></li>        
					  </ol>


					  <form action="<?php echo e(url('/updatepostingan')); ?>" method="post" enctype="multipart/form-data">
					  	<?php echo csrf_field(); ?>
					  <!-- content -->
					 <div class="form-group">
					 	<label>Masukan Judul Postingan</label>
					 	<input type="text" autocomplete="off" autofocus required name="judul" class="form-control" id="judul" placeholder="Masukan Judul Postingan" onkeyup="createslug()" value="<?php echo e($tampilkan->judul); ?>">
					 	<input type="hidden" name="slug" id="slug1" class="form-control" value="<?php echo e($tampilkan->slug); ?>">
					 	<input type="hidden" name="id" class="form-control" value="<?php echo e($tampilkan->id); ?>">
					 </div>

					 <div class="form-group">
					 	<label>Pilih Jenis Postingan</label>
					 	<select name="jenispost" required class="form-control">
					 		<option value="<?php echo e($tampilkan->jenispost); ?>"><?php echo e($tampilkan->jenispost); ?></option>
					 		<option value="Blogs">Blogs</option>
					 		<option value="Donasi">Donasi</option>
					 	</select>
					 </div>

					 <div class="form-group">
					 	<label>Masukan Isi Postingan</label><br/>
					 	<textarea name="isipostingan" id="editor"><?php echo e($tampilkan->isi); ?></textarea>
					 </div>

					 <div class="form-group">
						  <label>Masukan foto Depan Postingan</label>
						  <br/>
						  <font color="red">Ket: Input foto dengan ukuran width : 634 X height 357 px dengan ukuran kurang dari 1 mb untuk membuat website optimal</font>

	                        <div class="">
	                        	<div class="">
	                        		<input type="file"  name="foto" id="file" onchange="return fileValidation()" />
	                        	</div>
	                        	<br/><br/>
	                        	<div class="">
	                        	<div class="container">
	                        	<div class="card">
	                        		<!-- Image preview -->
	                        		<div class="card-body">
	                        			<div id="imagePreview"></div>
	                        		</div>
	                        	</div>
	                        	</div>
	                        	
	                        	</div>

	                        </div>
					 </div>

					 <center>
					 	<input type="submit" value="SIMPAN" class="btn btn-primary" name="simpan">
					 	<input type="reset" value="Reset" class="btn btn-default" name="reset">
					 </center>

					 </form>

			      </div>
			      <!-- end panel body -->

			    </div>
			  </div>
			  
			</div> 
			<!-- end dashboard admin --->

		</div>

	</div>
	<!-- penutup container -->

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>