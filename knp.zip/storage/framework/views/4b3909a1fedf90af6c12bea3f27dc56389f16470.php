<?php /* C:\xampp\htdocs\knp\resources\views/layouts/layout.blade.php */ ?>
<!DOCTYPE html>
<!-- halaman ini dikembangkan oleh team kokitindo.com -->
<!-- dan dimiliki oleh ketimbang ngemis pandeglang -->
<!-- hak cipta sepenuhnya diberikan kepada ketimbang ngemispandeglang -->
<html>
<head>
	<meta charset="utf-8">
    <meta name="keywords" content="Bootstrap, Landing page, Template, Registration, Landing">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="author" content="Grayrids">
    <style type="text/css">
      .navbar{
        background-color: black;
      }
    </style>
	<title><?php echo $__env->yieldContent('title'); ?></title>

	<!-- css internal -->
	<?php echo $__env->make('assets/css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- css external -->
	<?php echo $__env->yieldContent('css'); ?>


</head>
<body>

	<!-- ini adalah header -->
    <header id="home" class="hero-area-2">    
		<?php echo $__env->make('assets/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<?php echo $__env->yieldContent('halamanatas'); ?>
	</header>
	<!-- header end -->

	<!-- ini adalah content -->
	<content>
		<?php echo $__env->yieldContent('content'); ?>
	</content>

	<!-- preloader  dan top link -->
	<!-- Go To Top Link -->
    <a href="#" class="back-to-top">
      <i class="lni-chevron-up"></i>
    </a> 

    <!-- Preloader -->
    <div id="preloader">
      <div class="loader" id="loader-1"></div>
    </div>
    <!-- End Preloader -->

	<!-- ini adalah footer -->
	<footer>
    <!-- Footer Area Start -->
	<section class="footer-Content">
                  <div class="container">
                      
                      <center>
                        <img src="<?php echo e(asset('/images/knp.png')); ?>" style="width: 80px; height: 70px;">
                        <div class="textwidget">
                          <p> Komunitas - Ketimbang Ngemis Pandeglang, Pandeglang - Banten </p>
                        </div>
                      </center>
                    
                  </div>
                  <!-- Copyright Start  -->
                  <div class="copyright">
                    <div class="container">
                      <div class="row">
                        <div class="col-md-12">
                          <div class="site-info float-left">
                            <p>&copy; 2019 s/d <?php echo e(date('Y')); ?> - @ <a href="http://uideck.com" rel="nofollow">Kokitindo.com</a></p>
                          </div>              
                          <div class="float-right">  
                            <ul class="footer-social">
                              <li><a class="facebook" href="#"><i class="lni-facebook-filled"></i></a></li>
                              <li><a class="twitter" href="#"><i class="lni-twitter-filled"></i></a></li>
                              <li><a class="linkedin" href="#"><i class="lni-linkedin-fill"></i></a></li>
                              <li><a class="google-plus" href="#"><i class="lni-google-plus"></i></a></li>
                            </ul> 
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
    	<!-- Copyright End -->
	</section>
      <!-- Footer Section End --> 
	</footer>

	<!-- javascript internal -->
	<?php echo $__env->make('assets/javascript', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- javascript external -->
	<?php echo $__env->yieldContent('javascript'); ?>




</body>
</html>
