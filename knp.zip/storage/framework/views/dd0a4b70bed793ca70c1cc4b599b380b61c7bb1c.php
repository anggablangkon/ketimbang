<?php /* C:\xampp\htdocs\knp\resources\views/admin/form/tambahanggota.blade.php */ ?>
<?php $__env->startSection('title', 'Tambah data anggota komunitas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
		
		<div class="col-sm-3">
			
			<!-- membuat menu dashboar admin -->
			 <div class="panel-group" id="accordion">

			  <div class="panel panel-primary">
			    <div class="panel-heading">
			      <h4 class="panel-title">
			        <a data-toggle="collapse" style="text-decoration: none;" data-parent="#accordion" href="#collapse1">
			        Dashboard</a>
			      </h4>
			    </div>
			    <div id="collapse1" class="panel-collapse collapse in">
			      
			      <div class="panel-body">
			      <!-- content panel dashboard -->
			      	<?php echo $__env->make('assets/paneladmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			      <!-- end -->
			      </div>

			    </div>
			  </div>
			  
			</div> 
			<!-- end dashboard admin --->

		</div>

		<div class="col-sm-9">
			
			<!-- membuat menu dashboar admin -->
			 <div class="panel-group" id="accordion">

			  <div class="panel panel-primary">
			    <div class="panel-heading">
			      <h4 class="panel-title">
			        <a data-toggle="collapse" style="text-decoration: none;" data-parent="#accordion" href="#collapse2">
			        Hallo! <?php echo e(Auth::user()->name); ?></a>
			      </h4>
			    </div>
			    <div  class="panel-collapse collapse in">
			      <div class="panel-body">
			      <!-- content panel dashboard -->
			      <?php echo $__env->make('assets/message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			      <!-- breadacumb -->
			         <ol class="breadcrumb" style="background-color: none">
					    <li><a href="<?php echo e(url('/home')); ?>">Home</a></li>
					    <li><a href="<?php echo e(url('/tambahanggota')); ?>" class="activer">Tambah Anggota</a></li>        
					  </ol>


					  <!-- content -->
					  <form action="<?php echo e(url('/simpananggota')); ?>" method="post" enctype="multipart/form-data">
					  <?php echo csrf_field(); ?>
					  <div class="row">
					  	  <div class="col-sm-6">

					  	  <div class="form-group">
						    <label for="kdannggota">Kode Anggota </label>
						    <input type="text" placeholder="" class="form-control" style="width: 300px;" value="KNP-00<?php echo e($noanggota+1); ?>" disabled="">
						    <input type="hidden" placeholder="" class="form-control" style="width: 300px;" value="KNP-00<?php echo e($noanggota+1); ?>" name="noanggota">
						  </div>

					  	  <div class="form-group">
						    <label for="email">Nama Lengkap </label>
						    <input type="text" class="form-control" required="" name="nama" autocomplete="off"  style="width: 300px;">
						  </div>

						  <div class="form-group">
						    <label for="status">Status Keanggotaan </label>
						    <select name="statuskeanggotaan" required="" class="form-control" style="width: 300px;">
						    	<option value="Ketua">Ketua</option>
						    	<option value="Sekretaris">Sekretaris</option>
						    	<option value="Admin Media">Admin Media</option>
						    	<option value="Eksekutor">Eksekutor</option>
						    	<option value="Anggota">Anggota</option>
						    </select>
						  </div>

						  <b>Masukan foto disini</b><br/>
						  <font color="red">Ket: Input foto dengan ukuran kurang dari 1 mb untuk membuat website optimal</font>
	                        <div class="">
	                        	<div class="">
	                        		<input type="file" name="foto" id="file" onchange="return fileValidation()" />
	                        	</div>
	                        	<br/><br/>
	                        	<div class="">
	                        	<div class="container">
	                        	<div class="card">
	                        		<!-- Image preview -->
	                        		<div class="card-body">
	                        			<div id="imagePreview"></div>
	                        		</div>
	                        	</div>
	                        	</div>
	                        	
	                        	</div>

	                        </div>

						  </div>

						  <div class="col-sm-6">

					  	  <div class="form-group">
						    <label for="kdannggota">Alamat Facebook </label>
						    <input type="text" name="fb"  class="form-control" style="width: 300px;">
						  </div>

					  	  <div class="form-group">
						    <label for="email">Alamat Twitter </label>
						    <input type="text" name="email" class="form-control" autocomplete="off"  style="width: 300px;">
						  </div>

						  <div class="form-group">
						    <label for="status">Alamat Instagram </label>
						    <input type="text" name="ig" style="width: 300px;" class="form-control">
						  </div>

						  <div class="form-group">
						  	<button class="btn btn-primary">SIMPAN</button>
						  	<button type="reset" class="btn btn-default">RESET</button>
						  </div>

						  </div>




					  </div>
					  </form>


			      <!-- end -->
			      </div>

			    </div>
			  </div>
			  
			</div> 
			<!-- end dashboard admin --->


			<!-- membuat menu dashboar admin -->
			 <div class="panel-group" id="accordion">

			  <div class="panel panel-primary">
			    <div class="panel-heading">
			      <h4 class="panel-title">
			      </h4>
			    </div>
			    <div  class="panel-collapse collapse in">
			      
			      <div class="panel-body">
			      <!-- content panel dashboard -->

			      <!-- breadacumb -->
			         <ol class="breadcrumb" style="background-color: none">
					    <li><a href="<?php echo e(url('/home')); ?>">Home</a></li>
					    <li><a href="<?php echo e(url('/tambahanggota')); ?>" class="activer">Data Anggota</a></li>        
					  </ol>

					  <div class="table-responsive">

					  <table id="example" class="table table-striped table-bordered" style="width:100%">
				        <thead>
				            <tr>
				                <th>No</th>
				                <th>Nama</th>
				                <th>Status</th>
				                <th>Aksi</th>
				            </tr>
				        </thead>
				        <tbody>
				        	<?php $no = 1; ?>
				        	<?php $__currentLoopData = $dataanggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tampil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td><?php echo e($no++); ?></td>
				                <td><?php echo e($tampil->nama); ?></td>
				                <td><?php echo e($tampil->statusanggota); ?></td>
				                <td>
				                	<a href="" class="btn-xs btn-danger" data-toggle="modal" data-target="#myModal">Hapus</a>
				                	<!-- Modal digunakan untuk popuv delete data -->
									  <div class="modal fade" id="myModal" role="dialog">
									    <div class="modal-dialog">
									    
									      <!-- Modal content-->
									      <div class="modal-content">
									        <div class="modal-header">
									          <button type="button" class="close" data-dismiss="modal">&times;</button>
									          <h4 class="modal-title">Pemberitahuan Sistem</h4>
									        </div>
									        <div class="modal-body">
									          <p>Apakah Anda Yakin Akan Menghapus data <b><?php echo e($tampil->nama); ?></b></p>
									          <p>Jika Benar Tekan Tombol <a class="btn btn-danger" href="<?php echo e(url('/hapusanggota')); ?>/<?php echo e($tampil->noanggota); ?>">Hapus</a></p>
									        </div>
									        <div class="modal-footer">
									          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									        </div>
									      </div>
									      
									    </div>
									  </div>
				                	<a href="<?php echo e(url('/editanggota')); ?>/<?php echo e($tampil->noanggota); ?>"class="btn-xs btn-warning">Edit</a>
				                </td>
				            </tr>
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				      </table>

				      </div>

			      <!-- end -->
			      </div>

			    </div>
			  </div>
			  
			</div> 
			<!-- end dashboard admin --->

		</div>

	</div>
	<!-- penutup container -->

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>