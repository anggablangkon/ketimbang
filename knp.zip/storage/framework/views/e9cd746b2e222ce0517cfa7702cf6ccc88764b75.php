<?php /* C:\xampp\htdocs\knp\resources\views/assets/paneladmin.blade.php */ ?>
<a href="" class="btn btn-default btn-block">Panel Admin</a><br/>
<a href="<?php echo e(url('/tambahanggota')); ?>" class="btn btn-default btn-block">Tambah Anggota</a><br/>
<a href="<?php echo e(url('/tambahpostingan')); ?>" class="btn btn-default btn-block">Tambah Postingan</a><br/>
<a href="<?php echo e(url('/lihatpostingan')); ?>" class="btn btn-default btn-block">Lihat Postingan</a><br/>
<a class="btn btn-info btn-block" href="<?php echo e(route('logout')); ?>"
		onclick="event.preventDefault();
		document.getElementById('logout-form').submit();">
		<?php echo e(__('Keluar')); ?>

		</a>

		<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
			<?php echo csrf_field(); ?>
		</form>