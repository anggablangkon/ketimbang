<?php /* C:\xampp\htdocs\knp\resources\views/assets/css.blade.php */ ?>
	<link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/line-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/owl.carousel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/owl.theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/nivo-lightbox.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/main.css')); ?>">    
    <link rel="stylesheet" href="<?php echo e(asset('/css/responsive.css')); ?>">