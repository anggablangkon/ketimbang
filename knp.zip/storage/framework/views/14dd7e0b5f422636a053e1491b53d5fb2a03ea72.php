<?php /* C:\xampp\htdocs\knp\resources\views/layouts/layoutadmin.blade.php */ ?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
	

	<?php echo $__env->make('assets/cssadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body>

	<header>
		<!-- navbar admin -->
		<nav class="navbar navbar-inverse">
			<div class="container">
			<a href="<?php echo e(url('/')); ?>">	
				<p class="navbar-text" style="color: white">Halaman Utama Admin</p>
			</a>
			</div>
		</nav> 
		<!-- enf navbar -->
	</header>

	<content>
		<?php echo $__env->yieldContent('content'); ?>
	</content>

	<footer>
		<?php echo $__env->yieldContent('footer'); ?>
	</footer>


	<!-- javascript -->
  	<?php echo $__env->make('assets/javascriptadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>