<?php /* C:\xampp\htdocs\knp\resources\views//admin/lihatpostingan.blade.php */ ?>
<?php $__env->startSection('title', 'Tambah data anggota komunitas'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
		
		<div class="col-sm-3">
			
			<!-- membuat menu dashboar admin -->
			 <div class="panel-group" id="accordion">

			  <div class="panel panel-primary">
			    <div class="panel-heading">
			      <h4 class="panel-title">
			        <a data-toggle="collapse" style="text-decoration: none;" data-parent="#accordion" href="#collapse1">
			        Dashboard</a>
			      </h4>
			    </div>
			    <div id="collapse1" class="panel-collapse collapse in">
			      
			      <div class="panel-body">
			      <!-- content panel dashboard -->
			      	<?php echo $__env->make('assets/paneladmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			      <!-- end -->
			      </div>

			    </div>
			  </div>
			  
			</div> 
			<!-- end dashboard admin --->

		</div>

		<div class="col-sm-9">
			
			<!-- membuat menu dashboar admin -->
			 <div class="panel-group" id="accordion">

			  <div class="panel panel-primary">
			    <div class="panel-heading">
			      <h4 class="panel-title">
			        <a data-toggle="collapse" style="text-decoration: none;" data-parent="#accordion" href="#collapse2">
			        Hallo! <?php echo e(Auth::user()->name); ?></a>
			      </h4>
			    </div>
			    <div  class="panel-collapse collapse in">
			      <div class="panel-body">
			      <!-- content panel dashboard -->
			      <?php echo $__env->make('assets/message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			      <!-- breadacumb -->
			         <ol class="breadcrumb" style="background-color: none">
					    <li><a href="<?php echo e(url('/home')); ?>">Home</a></li>
					    <li><a href="<?php echo e(url('/lihatpostingan')); ?>" class="activer">Lihat Postingan</a></li>        
					  </ol>


					  <!-- content -->

					  <div class="table-responsive">


					  <table id="example" class="table table-striped table-bordered" style="width:100%">
				        <thead>
				            <tr>
				                <th>No</th>
				                <th>Judul</th>
				                <th>Tanggal Post</th>
				                <th>Jenis Post</th>
				                <th>Oleh</th>
				                <th>Aksi</th>
				            </tr>
				        </thead>
				        <tbody>
				        	<?php $no = 1; ?>
				            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tampil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				            <tr>
				                <td><?php echo e($no++); ?></td>
				                <td><?php echo e($tampil->judul); ?></td>
				                <td><?php echo e($tampil->date); ?></td>
				                <td>
				                	<?php if($tampil->jenispost == 'Donasi'): ?>
				                	<span class="label label-success"><?php echo e($tampil->jenispost); ?></span>
				                	<?php else: ?>
				                	<span class="label label-primary"><?php echo e($tampil->jenispost); ?></span>
				                	<?php endif; ?>
				                </td>
				                <td><?php echo e($tampil->cby); ?></td>
				                <td>
				                	<a href="" class="btn-xs btn-danger" data-toggle="modal" data-target="#myModal">Hapus</a>
				                	<!-- Modal digunakan untuk popuv delete data -->
									  <div class="modal fade" id="myModal" role="dialog">
									    <div class="modal-dialog">
									    
									      <!-- Modal content-->
									      <div class="modal-content">
									        <div class="modal-header">
									          <button type="button" class="close" data-dismiss="modal">&times;</button>
									          <h4 class="modal-title">Pemberitahuan Sistem</h4>
									        </div>
									        <div class="modal-body">
									          <p>Apakah Anda Yakin Akan Menghapus data <b><?php echo e($tampil->judul); ?></b></p>
									          <p>Jika Benar Tekan Tombol <a class="btn btn-danger" href="<?php echo e(url('/hapuspostingan')); ?>/<?php echo e($tampil->id); ?>">Hapus</a></p>
									        </div>
									        <div class="modal-footer">
									          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
									        </div>
									      </div>
									      
									    </div>
									  </div>
				                	<a  href="<?php echo e(url('/editpostingan')); ?>/<?php echo e($tampil->id); ?>" class="btn-xs btn-warning">Edit</a>
				                </td>
				            </tr>
				            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				      </table>

				  	  </div>
				  	  <!-- end table -->
				


			      <!-- end -->
			      </div>

			    </div>
			  </div>
			  
			</div> 
			<!-- end dashboard admin --->


		</div>

	</div>
	<!-- penutup container -->

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>