<?php /* C:\xampp\htdocs\knp\resources\views/assets/cssadmin.blade.php */ ?>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
    

	<style type="text/css">
		.navbar-inverse{
		 background-color:  #426edd;
		}
	</style>