<?php /* C:\xampp\htdocs\knp\resources\views/assets/javascript.blade.php */ ?>
<!-- jQuery first, then Tether, then Bootstrap JS. -->
    <script src="<?php echo e(asset('/js/jquery-min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/owl.carousel.js')); ?>"></script> 
    <script src="<?php echo e(asset('/js/jquery.mixitup.js')); ?>"></script>       
    <script src="<?php echo e(asset('/js/jquery.nav.js')); ?>"></script>    
    <script src="<?php echo e(asset('/js/scrolling-nav.js')); ?>"></script>    
    <script src="<?php echo e(asset('/js/jquery.easing.min.js')); ?>"></script>     
    <script src="<?php echo e(asset('/js/wow.js')); ?>"></script>   
    <script src="<?php echo e(asset('/js/jquery.counterup.min.js')); ?>"></script>     
    <script src="<?php echo e(asset('/js/nivo-lightbox.js')); ?>"></script>     
    <script src="<?php echo e(asset('/js/jquery.magnific-popup.min.js')); ?>"></script>     
    <script src="<?php echo e(asset('/js/waypoints.min.js')); ?>"></script>      
    <script src="<?php echo e(asset('/js/form-validator.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/contact-form-script.js')); ?>"></script>   
    <script src="<?php echo e(asset('/js/main.js')); ?>"></script>

    <!-- carausel -->
    