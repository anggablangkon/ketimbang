<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Auth;

class ArtikelController extends Controller
{
    public function bacapostingan($slug)
    {
    	//memgambil data untuk menampilkan postingan
    	$postingan    = DB::table('postingan')->where('slug', $slug)->first();

    	return view('/bacapostingan', ['postingan' => $postingan]);

    }

    public function lihatdonasi($slug)
    {
    	//memgambil data untuk menampilkan postingan
        $postingan    = DB::table('postingan')->where('slug', $slug)->first();

    	$donasi       = DB::table('postingan')->where('jenispost', 'donasi')->paginate(8);

    	return view('/lihatdonasi', ['postingan' => $postingan, 'donasi' => $donasi]);

    }


    public function aktifitasdandonasi()
    {
        $paginate  = $donasi = DB::table('postingan')->where('jenispost', 'donasi')->paginate(3);
        $paginate1 = $blogs  = DB::table('postingan')->where('jenispost', 'blogs')->paginate(3);

        return view('/aktifitasdandonasi', ['donasi' => $donasi, 'blogs' => $blogs, 'paginate' => $paginate, 'paginate1' => $paginate1]);
    }
}
